Documentation snapshot generated on 2025-08-30T03:05:47Z

backup-pre-sanitise: 13 files
main: 31 files
restructure-layout: 31 files

Suggested entry points:
- .doc/main/docs/overview.md
- .doc/main/README.md
- .doc/main/docs/architecture.md
- .doc/main/docs/quickstart.md
